Put the "Melon Client" folder in your .minecraft/versions folder

Put the "melonclient" folder in your .minecraft/libraries folder